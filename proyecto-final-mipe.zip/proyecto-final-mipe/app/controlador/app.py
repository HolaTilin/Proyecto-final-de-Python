"""
Controlador.

Le pide cosas al modelo y se las pasa a la vista.
No calcula ni imprime. Si aqui aparece un print(), algo se hizo mal.
"""
import csv
import os
import sqlite3

from app.modelo import exportador, indicadores, ingesta
from app.modelo.repositorio import CargaDuplicada, Repositorio
from app.vista import consola


class Aplicacion:

    def __init__(self, ruta_csv, ruta_bd, carpeta_output):
        self.ruta_csv = ruta_csv
        self.carpeta_output = carpeta_output
        self.repositorio = Repositorio(ruta_bd)

    def cargar(self):
        archivo = os.path.basename(self.ruta_csv)

        try:
            if self.repositorio.ya_se_cargo_hoy(archivo):
                consola.advertencia(f"El archivo {archivo} ya se cargó hoy.")
                return

            clientes, errores = ingesta.leer_csv(self.ruta_csv)
            unicos, duplicados = ingesta.quitar_duplicados(clientes)
            rechazados = len(errores)
            guardados = self.repositorio.guardar(
                unicos, archivo=archivo, rechazados=rechazados
            )
        except CargaDuplicada as error:
            consola.advertencia(str(error))
            return
        except (OSError, UnicodeError, csv.Error):
            consola.error(f"No se pudo leer {archivo}. Revisa que exista y esté en UTF-8.")
            return
        except sqlite3.Error:
            consola.error("No se pudo guardar la carga en SQLite.")
            return

        consola.mostrar_resultado_carga({
            "guardados": guardados,
            "duplicados": duplicados,
            "rechazados": rechazados,
            "motivos": ingesta.resumir_rechazos(errores),
        })

    def ver_indicadores(self):
        try:
            resultado = indicadores.calcular(self.repositorio.listar())
        except sqlite3.Error:
            consola.error("No se pudieron leer los clientes en SQLite.")
            return

        if not resultado:
            consola.advertencia("Primero carga la data del día con la opción 1.")
            return

        consola.mostrar_indicadores(resultado)

    def explorar(self):
        try:
            registros = self.repositorio.listar()
        except sqlite3.Error:
            consola.error("No se pudieron leer los clientes en SQLite.")
            return

        if not registros:
            consola.advertencia("Primero carga la data del día con la opción 1.")
            return

        ruc, sector = consola.pedir_filtros_exploracion()
        resultado = indicadores.explorar_cartera(registros, ruc, sector)
        consola.mostrar_exploracion(resultado)

    def generar_entregable(self):
        try:
            registros = self.repositorio.listar()
        except sqlite3.Error:
            consola.error("No se pudieron leer los clientes en SQLite.")
            return

        if not registros:
            consola.advertencia("Primero carga la data del día con la opción 1.")
            return

        try:
            ruta, filas = exportador.generar(registros, self.carpeta_output)
        except OSError:
            consola.error(
                "No se pudo guardar el CSV. Revisa la carpeta de salida "
                "o cierra el archivo si está abierto."
            )
            return

        consola.mensaje(f"Entregable generado con {filas} clientes.\n  {ruta}")

    def ver_historial(self):
        try:
            cargas = self.repositorio.historial()
        except sqlite3.Error:
            consola.error("No se pudo consultar el historial de cargas.")
            return

        consola.mostrar_historial(cargas)

    def ejecutar(self):
        acciones = {
            "1": self.cargar,
            "2": self.ver_indicadores,
            "3": self.explorar,
            "4": self.generar_entregable,
            "5": self.ver_historial,
        }
        while True:
            consola.mostrar_menu()
            opcion = consola.pedir_opcion()
            if opcion == "6":
                consola.mensaje("Fin del proceso.")
                return
            accion = acciones.get(opcion)
            if accion is None:
                consola.advertencia("Esa opcion no existe.")
            else:
                accion()
