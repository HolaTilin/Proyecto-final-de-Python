"""
Calculo de indicadores con pandas.

Regla: el DataFrame NO sale de este archivo. Hacia afuera se devuelven
listas y diccionarios, para que la vista no sepa que pandas existe.

Revisa TEMATICAS.md: ahi estan los indicadores minimos de tu tema.
"""

import pandas as pd
from app.modelo.entidades import Cliente, NIVELES_RIESGO

def clasificar_cartera(registros):
    return [
        dict(registro, nivel_riesgo=Cliente(**registro).clasificar())
        for registro in registros
    ]


def calcular(registros):
    if not registros:
        return {}

    df = pd.DataFrame(clasificar_cartera(registros))
    por_riesgo = (
        df.groupby("nivel_riesgo")
        .agg(clientes=("ruc", "size"), monto_expuesto=("saldo_actual", "sum"))
        .reindex(NIVELES_RIESGO, fill_value=0)
        .reset_index()
    )
    saldo_por_sector = df.groupby("sector")["saldo_actual"].mean()
    top_10 = (
        df.sort_values(["saldo_actual", "ruc"], ascending=[False, True])
        .head(10)[["ruc", "razon_social", "saldo_actual", "nivel_riesgo"]]
    )

    return {
        "monto_expuesto_total": float(df["saldo_actual"].sum()),
        "por_riesgo": por_riesgo.to_dict("records"),
        "saldo_promedio_por_sector": saldo_por_sector.to_dict(),
        "top_10": top_10.to_dict("records"),
    }

def explorar_cartera(registros, ruc="", sector=""):
    if not registros:
        return {"total": 0, "clientes": []}

    df = pd.DataFrame(registros)

    if ruc:
        df = df[df["ruc"] == ruc]

    if sector:
        df = df[df["sector"].str.casefold() == sector.casefold()]

    muestra = df.sort_values(
        ["saldo_actual", "ruc"], ascending=[False, True]
    ).head(10)

    return {
        "total": len(df),
        "clientes": clasificar_cartera(muestra.to_dict("records")),
    }