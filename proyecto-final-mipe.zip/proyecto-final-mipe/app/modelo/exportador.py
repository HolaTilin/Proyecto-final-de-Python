"""
Generacion del entregable.

El final del flujo: el archivo que recibe la otra area.
Ponle la fecha en el nombre para que el de hoy no pise el de ayer.
"""

import os
from datetime import date
from tempfile import NamedTemporaryFile

import pandas as pd

from app.modelo.indicadores import clasificar_cartera


def generar(registros, carpeta_output):
    columnas = {
        "ruc": "RUC",
        "razon_social": "Razón social",
        "sector": "Sector",
        "departamento": "Departamento",
        "monto_otorgado": "Monto otorgado",
        "saldo_actual": "Saldo actual",
        "dias_atraso": "Días de atraso",
        "ventas_anuales": "Ventas anuales",
        "antiguedad_meses": "Antigüedad en meses",
        "fecha_desembolso": "Fecha de desembolso",
        "nivel_riesgo": "Nivel de riesgo",
    }

    df = pd.DataFrame(clasificar_cartera(registros), columns=list(columnas))
    df = df.sort_values(
        ["saldo_actual", "ruc"], ascending=[False, True]
    ).rename(columns=columnas)

    os.makedirs(carpeta_output, exist_ok=True)
    nombre = f"cartera_mipe_{date.today().isoformat()}.csv"
    ruta = os.path.join(carpeta_output, nombre)

    with NamedTemporaryFile(
        dir=carpeta_output, suffix=".tmp", delete=False
    ) as temporal:
        ruta_temporal = temporal.name

    try:
        df.to_csv(
            ruta_temporal,
            index=False,
            sep=";",
            decimal=",",
            encoding="utf-8-sig",
            float_format="%.2f",
        )
        os.replace(ruta_temporal, ruta)
    finally:
        if os.path.exists(ruta_temporal):
            os.remove(ruta_temporal)

    return ruta, len(df)