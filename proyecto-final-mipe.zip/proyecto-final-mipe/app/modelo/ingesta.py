"""
Lectura y validacion del archivo del dia.

Regla que no se negocia: una fila mala nunca tumba la carga.
Se rechaza, se anota el motivo y se sigue con la siguiente.
"""

import csv
from app.modelo.entidades import Cliente

def leer_csv(ruta):
    clientes = []
    errores = []
    with open(ruta, encoding="utf-8") as file:
        lector = csv.DictReader(file)
        for numero, fila in enumerate(lector, start=2):
            try:
             cliente = Cliente.desde_fila(fila)
             clientes.append(cliente)
            except ValueError as error:
             errores.append({"fila": numero, "motivo": str(error)})
        
        return clientes, errores


def quitar_duplicados(registros):
    """
    TODO: el CSV trae filas repetidas. Deja una sola por identificador.

    Devuelve (unicos, cantidad_descartada).
    """
    clientes_por_ruc = {}
    duplicados = 0

    for cliente in registros:
        ruc = cliente.ruc
        if ruc in clientes_por_ruc:
            duplicados += 1
        else:
            clientes_por_ruc[ruc] = cliente

    return list(clientes_por_ruc.values()), duplicados

def resumir_rechazos(errores):
    motivos = {}
    for error in errores:
        motivo = error["motivo"]
        motivos[motivo] = motivos.get(motivo, 0) + 1
    return motivos