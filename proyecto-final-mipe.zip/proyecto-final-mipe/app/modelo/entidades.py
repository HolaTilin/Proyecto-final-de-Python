"""
Clases de dominio de TU tematica.

Aqui vive la regla de negocio. Si tu tematica es cobranzas, la clase se
llamara Deuda; si es inventario, Producto. El nombre importa: debe ser
la palabra que usa el area, no "Dato" ni "Registro".
"""
from datetime import date, datetime

def a_decimal(texto):
    """Convierte texto a decimal. Acepta coma o punto."""
    if texto is None:
        raise ValueError("valor vacio")
    texto = str(texto).strip().replace(",", ".")
    if texto == "":
        raise ValueError("valor vacio")
    return float(texto)


def a_entero(texto):
    numero = a_decimal(texto)
    if not numero.is_integer():
        raise ValueError("Se esperaba un número entero")
    return int(numero)

NIVELES_RIESGO = ("Normal", "Con Problemas", "Deficiente", "Dudoso", "Pérdida")
class Cliente:
    """
    TODO: renombra esta clase con el nombre real de tu entidad.

    Sus atributos son las columnas del CSV que generaste.
    """

    def __init__(
        self, ruc, razon_social, sector, departamento,
        monto_otorgado, saldo_actual, dias_atraso, ventas_anuales,
        antiguedad_meses, fecha_desembolso,
    ):
        self.ruc = ruc
        self.razon_social = razon_social
        self.sector = sector
        self.departamento = departamento
        self.monto_otorgado = monto_otorgado
        self.saldo_actual = saldo_actual
        self.dias_atraso = dias_atraso
        self.ventas_anuales = ventas_anuales
        self.antiguedad_meses = antiguedad_meses
        self.fecha_desembolso = fecha_desembolso

    @classmethod
    def desde_fila(cls, fila):
        """
        TODO: construye el objeto a partir de una fila del CSV.

        Si la fila no sirve, levanta ValueError explicando el motivo.
        Valida al menos: campos obligatorios, tipos y rangos imposibles
        (montos negativos, fechas futuras, etc.).
        """
        ruc = (fila.get("ruc") or "").strip()
        if not ruc:
            raise ValueError("El RUC está vacío")
        try:
                monto_otorgado = a_decimal(fila.get("monto_otorgado"))
        except ValueError:
                raise ValueError("El monto otorgado está vacío o tiene un formato inválido")

        if monto_otorgado < 0:
         raise ValueError("El monto otorgado no puede ser negativo")
        
        try:
         saldo_actual = a_decimal(fila.get("saldo_actual"))
        except ValueError:
         raise ValueError("El saldo actual está vacío o tiene un formato inválido")

        if saldo_actual < 0:
         raise ValueError("El saldo actual no puede ser negativo")
        try:
         ventas_anuales = a_decimal(fila.get("ventas_anuales"))
        except ValueError:
         raise ValueError("Las ventas anuales están vacías o tienen un formato inválido")

        if ventas_anuales < 0:
         raise ValueError("Las ventas anuales no pueden ser negativas")

        try:
         dias_atraso = a_entero(fila.get("dias_atraso"))
        except ValueError:
         raise ValueError("Los días de atraso deben ser un número entero")

        if dias_atraso < 0:
         raise ValueError("Los días de atraso no pueden ser negativos")

        try:
         antiguedad_meses = a_entero(fila.get("antiguedad_meses"))
        except ValueError:
         raise ValueError("La antigüedad debe ser un número entero de meses")

        if antiguedad_meses < 0:
         raise ValueError("La antigüedad no puede ser negativa")

        texto_fecha = (fila.get("fecha_desembolso") or "").strip()

        for formato in ("%Y-%m-%d", "%d/%m/%Y"):
            try:
                fecha_desembolso = datetime.strptime(texto_fecha, formato).date()
                break
            except ValueError:
                continue
        else:
            raise ValueError("La fecha de desembolso está vacía o no es válida")

        if fecha_desembolso > date.today():
            raise ValueError("La fecha de desembolso no puede estar en el futuro")
        
        razon_social = (fila.get("razon_social") or "").strip()
        if not razon_social:
         raise ValueError("La razón social está vacía")

        sector = (fila.get("sector") or "").strip().title()
        if not sector:
         raise ValueError("El sector está vacío")

        departamento = (fila.get("departamento") or "").strip().title()
        if not departamento:
         raise ValueError("El departamento está vacío")

        return cls(
            ruc=ruc,
            razon_social=razon_social,
            sector=sector,
            departamento=departamento,
            monto_otorgado=monto_otorgado,
            saldo_actual=saldo_actual,
            dias_atraso=dias_atraso,
            ventas_anuales=ventas_anuales,
            antiguedad_meses=antiguedad_meses,
            fecha_desembolso=fecha_desembolso.isoformat(),
        )

    def clasificar(self):
        if self.dias_atraso <= 8:
            nivel = 0
        elif self.dias_atraso <= 30:
            nivel = 1
        elif self.dias_atraso <= 60:
            nivel = 2
        elif self.dias_atraso <= 120:
            nivel = 3
        else:
            nivel = 4

        if self.saldo_actual > 0 and self.saldo_actual >= self.ventas_anuales * 0.50:
            nivel = min(nivel + 1, 4)

        return NIVELES_RIESGO[nivel]

    def como_diccionario(self):
        """
        TODO: devuelve los datos como diccionario.

        La vista NO debe recibir objetos del modelo.
        """
        raise NotImplementedError
