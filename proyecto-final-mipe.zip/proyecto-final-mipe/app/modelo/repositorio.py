"""
Persistencia en SQLite.

Dos tablas como minimo:
  - la de tu entidad, con su identificador como PRIMARY KEY
  - una tabla de cargas, para saber que dia se cargo que archivo

La segunda es la que impide cargar dos veces el mismo dia.

Advertencia de rendimiento: NO pongas commit() dentro del bucle de
insercion. Con 50 000 filas se vuelve de cientos a miles de veces mas
lento. Usa executemany() y un solo commit al final.
"""

import os
import sqlite3
from datetime import date

ESQUEMA = """
CREATE TABLE IF NOT EXISTS clientes (
    ruc TEXT NOT NULL PRIMARY KEY,
    razon_social TEXT NOT NULL,
    sector TEXT NOT NULL,
    departamento TEXT NOT NULL,
    monto_otorgado REAL NOT NULL,
    saldo_actual REAL NOT NULL,
    dias_atraso INTEGER NOT NULL,
    ventas_anuales REAL NOT NULL,
    antiguedad_meses INTEGER NOT NULL,
    fecha_desembolso TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cargas (
    fecha TEXT NOT NULL,
    archivo TEXT NOT NULL,
    validos INTEGER NOT NULL,
    rechazados INTEGER NOT NULL,
    PRIMARY KEY (fecha, archivo)
);
"""


class CargaDuplicada(Exception):
    """Se intento cargar el mismo archivo dos veces el mismo dia."""


class Repositorio:

    def __init__(self, ruta_bd):
        carpeta = os.path.dirname(ruta_bd)
        if carpeta:
            os.makedirs(carpeta, exist_ok=True)

        self.conexion = sqlite3.connect(ruta_bd)
        self.conexion.executescript(ESQUEMA)
        self.conexion.commit()

    def guardar(self, registros, forzar=False, archivo="", rechazados=0):
        sql = """
            INSERT INTO clientes (
                ruc, razon_social, sector, departamento, monto_otorgado,
                saldo_actual, dias_atraso, ventas_anuales,
                antiguedad_meses, fecha_desembolso
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(ruc) DO UPDATE SET
                razon_social = excluded.razon_social,
                sector = excluded.sector,
                departamento = excluded.departamento,
                monto_otorgado = excluded.monto_otorgado,
                saldo_actual = excluded.saldo_actual,
                dias_atraso = excluded.dias_atraso,
                ventas_anuales = excluded.ventas_anuales,
                antiguedad_meses = excluded.antiguedad_meses,
                fecha_desembolso = excluded.fecha_desembolso
        """

        filas = [
            (
                c.ruc, c.razon_social, c.sector, c.departamento, c.monto_otorgado,
                c.saldo_actual, c.dias_atraso, c.ventas_anuales,
                c.antiguedad_meses, c.fecha_desembolso,
            )
            for c in registros
        ]

        with self.conexion:
            if archivo:
                self.registrar_carga(archivo, len(filas), rechazados, forzar=forzar)
            cursor = self.conexion.executemany(sql, filas)

        return cursor.rowcount

    def ya_se_cargo_hoy(self, archivo):
        fila = self.conexion.execute(
            "SELECT 1 FROM cargas WHERE fecha = ? AND archivo = ?",
            (date.today().isoformat(), archivo),
        ).fetchone()
        return fila is not None

    def registrar_carga(self, archivo, validos, rechazados, forzar=False):
        cursor = self.conexion.execute(
            """
            INSERT INTO cargas (fecha, archivo, validos, rechazados)
            VALUES (?, ?, ?, ?)
            ON CONFLICT (fecha, archivo) DO UPDATE SET
                validos = excluded.validos,
                rechazados = excluded.rechazados
            WHERE ?
            """,
            (date.today().isoformat(), archivo, validos, rechazados, forzar),
        )
        if cursor.rowcount == 0:
            raise CargaDuplicada(f"El archivo {archivo} ya se cargó hoy.")

    def historial(self, limite=15):
        cursor = self.conexion.cursor()
        cursor.row_factory = sqlite3.Row
        cursor.execute(
            """
            SELECT fecha, archivo, validos, rechazados
            FROM cargas
            ORDER BY fecha DESC, archivo ASC
            LIMIT ?
            """,
            (limite,),
        )
        return [dict(fila) for fila in cursor.fetchall()]


    def listar(self):
        cursor = self.conexion.cursor()
        cursor.row_factory = sqlite3.Row
        cursor.execute("SELECT * FROM clientes")
        return [dict(fila) for fila in cursor.fetchall()]

    def cerrar(self):
        raise NotImplementedError
