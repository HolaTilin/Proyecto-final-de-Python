"""
Capa de vista.

Este es el UNICO archivo donde pueden aparecer print(), input() y la
libreria de consola. Si aparecen en otra capa, el MVC esta roto.

La vista no calcula nada: recibe datos listos y los muestra.
"""


class SalidaSolicitada(Exception):
    """El usuario cerro la entrada con Ctrl+D (o Ctrl+Z en Windows)."""


def pedir_opcion(mensaje="  Opcion: "):
    try:
        return input(mensaje).strip()
    except EOFError:
        raise SalidaSolicitada()


def mostrar_menu():
    """TODO: el panel de control de tu herramienta."""
    print()
    print("  1. Cargar data del dia")
    print("  2. Ver indicadores")
    print("  3. Explorar la data")
    print("  4. Generar entregable")
    print("  5. Historial de cargas")
    print("  6. Salir")


def mensaje(texto):
    print("\n  {}".format(texto))


def advertencia(texto):
    print("\n  [!] {}".format(texto))


def error(texto):
    print("\n  [ERROR] {}".format(texto))


def mostrar_resultado_carga(resultado):
    print(f"  {resultado['guardados']} clientes guardados.")
    print(f"  {resultado['duplicados']} duplicados descartados.")
    print(f"  {resultado['rechazados']} filas rechazadas.")
    for motivo, cantidad in resultado["motivos"].items():
        print(f"    {cantidad} filas - {motivo}")


def mostrar_indicadores(indicadores):
    print(f"\n  Exposición total {indicadores['monto_expuesto_total']:,.2f}")

    print("\n  Clientes y exposición por nivel de riesgo")
    for fila in indicadores["por_riesgo"]:
        print(
            f"  {fila['nivel_riesgo']:<14} {fila['clientes']:>6} clientes  "
            f"{fila['monto_expuesto']:>16,.2f}"
        )

    print("\n  Saldo promedio por sector")
    for sector, promedio in indicadores["saldo_promedio_por_sector"].items():
        print(f"  {sector:<16} {promedio:>14,.2f}")

    print("\n  Diez clientes con mayor exposición")
    for fila in indicadores["top_10"]:
        print(
            f"  {fila['ruc']}  {fila['razon_social']}  "
            f"{fila['saldo_actual']:,.2f}  {fila['nivel_riesgo']}"
        )

def pedir_filtros_exploracion():
    ruc = pedir_opcion("  RUC (Enter para omitir): ")
    sector = pedir_opcion("  Sector (Enter para omitir): ")
    return ruc, sector


def mostrar_exploracion(resultado):
    clientes = resultado["clientes"]
    if not clientes:
        advertencia("No se encontraron clientes con esos filtros.")
        return

    print(f"\n  Mostrando {len(clientes)} de {resultado['total']} coincidencias.")
    print("  RUC | Razón social | Sector | Departamento | Días de atraso | Saldo | Riesgo")

    for cliente in clientes:
        print(
            f"  {cliente['ruc']} | {cliente['razon_social']} | {cliente['sector']} | "
            f"{cliente['departamento']} | {cliente['dias_atraso']} | "
            f"{cliente['saldo_actual']:,.2f} | {cliente['nivel_riesgo']}"
        )
def mostrar_historial(cargas):
    if not cargas:
        advertencia("Todavía no hay cargas registradas.")
        return

    print("\n  Fecha | Archivo | Clientes guardados | Filas rechazadas")
    for carga in cargas:
        print(
            f"  {carga['fecha']} | {carga['archivo']} | "
            f"{carga['validos']} | {carga['rechazados']}"
        )
        
